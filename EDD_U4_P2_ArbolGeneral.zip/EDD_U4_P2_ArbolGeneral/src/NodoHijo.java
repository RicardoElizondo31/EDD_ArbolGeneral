/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class NodoHijo {
    NodoArbolGeneral direccionHijo;
    NodoHijo ant, sig;
    
    public NodoHijo(NodoArbolGeneral hijoAapuntar){
        direccionHijo = hijoAapuntar;
        ant = sig = null;
    }

    public NodoArbolGeneral getDireccionHijo() {
        return direccionHijo;
    }

    public void setDireccionHijo(NodoArbolGeneral direccionHijo) {
        this.direccionHijo = direccionHijo;
    }

    public NodoHijo getAnt() {
        return ant;
    }

    public void setAnt(NodoHijo ant) {
        this.ant = ant;
    }

    public NodoHijo getSig() {
        return sig;
    }

    public void setSig(NodoHijo sig) {
        this.sig = sig;
    }
    
}
