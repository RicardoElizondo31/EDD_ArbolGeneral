/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class ArbolGeneral {
    NodoArbolGeneral raiz;
    int nivel;
    
    public ArbolGeneral(){
        raiz = null;
    }
    
    public boolean insertar(char dato, String path){
        //Raiz=null? Si->Se crea nodo
        if(raiz == null){
            raiz = new NodoArbolGeneral(dato);
            if(raiz == null) return false;
            return true;
        }
        //Si path esta vacio-> se retorna falso
        //Si path no esta vacio->se crea nodo y despues enlazamos
        if(path.isEmpty()) return false;
        
        NodoArbolGeneral padre = busquedaRecursiva(path, path);
        if(padre == null) return false;
  
        NodoArbolGeneral nuevo = new NodoArbolGeneral(dato);
        return padre.enlazar(nuevo);
    }

    
    
    private NodoArbolGeneral busqueda(String path) {  
        path = path.substring(1);
        //Quitamos diagonales del path con un split y se convierte en un vector
        String vector[] = path.split("/");
        //Comienza la busqueda nodo por nodo
        if(vector[0].charAt(0) == raiz.dato){
           //Un solo nodo->Se retorna el valor de la raiz
           if(vector.length == 1) return raiz;
            NodoArbolGeneral padre = raiz;
            for(int i = 1; i < vector.length; i++){
                padre = padre.obtenerHijo(vector[i].charAt(0));
                if(padre == null) return null;
            }
            return padre;
        }
        return null;   
    }
    
    
    private NodoArbolGeneral busquedaRecursiva(String path , String igual) {  
        int tam = 0;
        int tam2 = 0;

        path = path.substring(1);

        tam = path.length();
        tam2 = igual.length();
        tam2 = tam2 /2 ;
        if(igual.charAt(1) == raiz.dato){

           if(tam2 == 1) return raiz;
            NodoArbolGeneral padre = raiz;
                
            if(tam == 0){
                padre = padre.obtenerHijo(path.charAt(0));
                busquedaRecursiva(path.substring(1), igual);
            }
            if(padre == null) return null;
            return padre;
        }
        return null;   
    }
  
    
    
    public boolean eliminar(String path){
        if(raiz == null) return false;        
        NodoArbolGeneral hijo = busqueda(path);
        if(hijo == null) return false;
        if(!hijo.esHoja()) return false;
        if(hijo == raiz){
            raiz = null;
            return true;
        }
        
        String pathPadre= obtenerPathPadre(path);
        NodoArbolGeneral padre = busqueda(path);
        
        return padre.desenlazar(hijo);
    }

    private String obtenerPathPadre(String path) {
        int pathRes = path.lastIndexOf("/")-1;
        return path.substring(0, pathRes);
    }   
}
